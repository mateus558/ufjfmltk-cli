# cppcli: A CLI composer for C++
[![CMake](https://github.com/mateus558/cppcli/actions/workflows/cmake.yml/badge.svg)](https://github.com/mateus558/cppcli/actions/workflows/cmake.yml)

A simple framework for composing command line interfaces for C++, it's structure is based on how things are done in the 
Qt framework.
