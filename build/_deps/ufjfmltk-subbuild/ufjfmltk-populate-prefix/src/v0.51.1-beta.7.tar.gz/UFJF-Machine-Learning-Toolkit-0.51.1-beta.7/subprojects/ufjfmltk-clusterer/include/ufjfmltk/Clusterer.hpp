#pragma once

#include "ufjfmltk/clusterer/Clusterer.hpp"
#include "ufjfmltk/clusterer/KMeans.hpp"