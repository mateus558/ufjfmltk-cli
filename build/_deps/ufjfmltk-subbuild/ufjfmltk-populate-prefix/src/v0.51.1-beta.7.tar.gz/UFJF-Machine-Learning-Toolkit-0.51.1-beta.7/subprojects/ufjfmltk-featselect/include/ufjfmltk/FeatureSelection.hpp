#pragma once

#include "ufjfmltk/featselect/FeatureSelection.hpp"
#include "ufjfmltk/featselect/AOS.hpp"
#include "ufjfmltk/featselect/Fisher.hpp"
#include "ufjfmltk/featselect/Golub.hpp"
#include "ufjfmltk/featselect/RFE.hpp"