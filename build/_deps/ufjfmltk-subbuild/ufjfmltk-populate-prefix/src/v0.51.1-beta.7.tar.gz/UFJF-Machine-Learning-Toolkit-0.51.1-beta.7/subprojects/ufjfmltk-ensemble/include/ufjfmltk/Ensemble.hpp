#pragma once

#include "ufjfmltk/ensemble/Ensemble.hpp"
#include "ufjfmltk/ensemble/VotingClassifier.hpp"
#include "ufjfmltk/ensemble/AdaBoostClassifier.hpp"
#include "ufjfmltk/ensemble/BaggingClassifier.hpp"
#include "ufjfmltk/ensemble/PerceptronCommittee.hpp"
