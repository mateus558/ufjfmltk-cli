#pragma once

#include "ufjfmltk/classifier/Classifier.hpp"
#include "ufjfmltk/classifier/DualClassifier.hpp"
#include "ufjfmltk/classifier/IMA.hpp"
#include "ufjfmltk/classifier/KNNClassifier.hpp"
#include "ufjfmltk/classifier/OneVsAll.hpp"
#include "ufjfmltk/classifier/OneVsOne.hpp"
#include "ufjfmltk/classifier/Perceptron.hpp"
#include "ufjfmltk/classifier/PrimalClassifier.hpp"
#include "ufjfmltk/classifier/SMO.hpp"