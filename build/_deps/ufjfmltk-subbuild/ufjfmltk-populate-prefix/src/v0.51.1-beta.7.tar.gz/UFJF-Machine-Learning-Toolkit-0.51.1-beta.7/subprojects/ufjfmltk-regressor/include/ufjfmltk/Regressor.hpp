#pragma once

#include "ufjfmltk/regressor/DualRegressor.hpp"
#include "ufjfmltk/regressor/KNNRegressor.hpp"
#include "ufjfmltk/regressor/LMS.hpp"
#include "ufjfmltk/regressor/PrimalRegressor.hpp"
#include "ufjfmltk/regressor/Metrics.hpp"
#include "ufjfmltk/regressor/Regressor.hpp"